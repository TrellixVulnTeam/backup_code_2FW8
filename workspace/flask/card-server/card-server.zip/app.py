from src.application import create_app
from src.models import *

app = create_app()