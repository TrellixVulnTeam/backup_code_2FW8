from flask import Blueprint, jsonify, request

user = Blueprint('user', __name__)