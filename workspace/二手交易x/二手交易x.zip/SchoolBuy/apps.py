from django.apps import AppConfig


class SchoolbuyConfig(AppConfig):
    name = 'SchoolBuy'
