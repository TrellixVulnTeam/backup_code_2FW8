# ✈FeiJiDaZhan
---

### 运行： python FeiJiDaZhan.py
#### 安装pygame：pip install pygame

#### 版本：Python3

Python语言的Pygame模块编写的飞机大战小游戏，内含源码和exe文件。

使用 py2exe 模块将文件打包成可执行文件，最好在windows打包，linux可能报错，缺少某个文件。

##### 注：只能在python3.0+运行。

不同的电脑配置将导致游戏流畅度不同。如需修改，请修改倒数第三行代码(time.sleep())的参数值。
