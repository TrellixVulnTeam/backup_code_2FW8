The themes 
* aeon_desktop,
* metalworks_desktop,
* metalworks_mobile,
* minimal_desktop,
* minimal_mobile
and 
* topcoat_light_mobile

are based on the [feathers themes](https://github.com/BowlerHatLLC/feathers/tree/master/themes) by Josh Tynjala
