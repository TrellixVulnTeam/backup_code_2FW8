// import { Application, loader, particles, Sprite } from 'pixi.js'
// import * as particles from "pixi-particles"
// const app = new Application()

// document.body.appendChild(app.view)
// loader.add("images/star.png").load(setup)

// function setup() {
//     // const pp = new particles.ParticleContainer(10000, {
//     //     scale: true,
//     //     position: true,
//     //     rotation: true,
//     //     uvs: true,
//     //     alpha: true
//     // })

//     // for (let i = 0; i < 10000; i++) {
//     //     const ch = Sprite.fromImage("images/star.png")
//     //     pp.addChild(ch)
//     // }

//     app.stage.addChild(pp)
    
// //     const inputName = createTextInput({
// //         placeholder: "请输入游戏名称",
// //         x: 400,
// //         y: 200
// //     })

// //     app.stage.addChild(inputName)
// // }

// // const inputDefaultStyle = {
// //     fontSize: '25pt',
// //     padding: '14px',
// //     width: '500px',
// //     color: '#26272E',
// // }

// // function createTextInput(options, textStyle = {}) {
// //     Object.assign(textStyle, inputDefaultStyle)
// //     const input = new PIXI.TextInput(textStyle)
// //     input.pivot.x = input.width / 2
// //     input.pivot.y = input.height / 2

// //     for (let key in options) {
// //         input[key] = options[key]
// //     }

// //     return input
// // }