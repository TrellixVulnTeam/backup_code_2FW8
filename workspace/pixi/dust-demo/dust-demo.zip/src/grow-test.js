import { Application, loader, particles, Sprite, Container, Rectangle } from 'pixi.js'
import * as GROW from 'grow.js'
const app = new Application()

document.body.appendChild(app.view)
console.log(GROW)