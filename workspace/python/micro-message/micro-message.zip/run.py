from app import app
app.debug = True
# app.run(debug=True)