# notakto-3-board

AI is the first step, a winning strategy

algorithm explained in this paper: http://arxiv.org/pdf/1301.1672v1.pdf
