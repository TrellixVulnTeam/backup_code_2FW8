# -*- coding: utf-8 -*-

class InvalieMove(StandardError):
    pass
