# Create your tests here.

class pagiton():
    hasHead = True
    hasEnd = True
    list = []
    now = 0
    end = 0
    canshu = ''
