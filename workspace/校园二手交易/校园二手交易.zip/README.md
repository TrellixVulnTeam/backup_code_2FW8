
后台管理地址：127.0.0.1:8000/admin/
后台管理密码：root
            rootisgad