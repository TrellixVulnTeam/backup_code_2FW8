"use strict";
cc._RF.push(module, 'b7faavtW3RPCo6evqZ+YG89', 'BtnCallbacks');
// scripts/BtnCallbacks.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var WagerState_1 = require("./WagerState");
var GameState_1 = require("./GameState");
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var BtnCallbacks = /** @class */ (function (_super) {
    __extends(BtnCallbacks, _super);
    function BtnCallbacks() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    BtnCallbacks_1 = BtnCallbacks;
    BtnCallbacks.prototype.IncWager = function (item) {
        this.AddWager(item, 1);
    };
    BtnCallbacks.prototype.AddWager = function (item, value) {
        if (GameState_1.default.get('coin') >= value) {
            WagerState_1.default.add(item, value);
            GameState_1.default.add('coin', -value * BtnCallbacks_1.mp);
        }
    };
    //每一项+1
    BtnCallbacks.prototype.AllPlusOne = function () {
        var _this = this;
        BtnCallbacks_1.allWagers.forEach(function (key) {
            _this.IncWager(key);
        });
    };
    //投注减半
    BtnCallbacks.prototype.RecuceHalfWager = function () {
        var _this = this;
        BtnCallbacks_1.allWagers.forEach(function (key) {
            var halfCount = Math.floor(WagerState_1.default.get(key) / 2);
            if (WagerState_1.default.get(key) === 1) {
                halfCount = 1;
            }
            _this.AddWager(key, -halfCount);
        });
    };
    //投注加倍
    BtnCallbacks.prototype.DoubleWager = function () {
        var _this = this;
        BtnCallbacks_1.allWagers.forEach(function (key) {
            var count = WagerState_1.default.get(key);
            _this.AddWager(key, count);
        });
    };
    //重置所有状态
    BtnCallbacks.prototype.Reset = function () {
        if (GameState_1.default.get('coin') <= 0) {
            WagerState_1.default.clean();
            GameState_1.default.clean();
            GameState_1.default.set('coin', 100);
        }
    };
    var BtnCallbacks_1;
    BtnCallbacks.allWagers = ['apple', 'orange', 'mongo', 'ring', 'watermelon', '77', 'star', 'bar'];
    BtnCallbacks.mp = 10;
    BtnCallbacks = BtnCallbacks_1 = __decorate([
        ccclass
    ], BtnCallbacks);
    return BtnCallbacks;
}(cc.Component));
exports.default = BtnCallbacks;

cc._RF.pop();