"use strict";
cc._RF.push(module, 'c0a7dK4vENLe7Ppd9BOlK+d', 'GameState');
// scripts/GameState.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var State_1 = require("./State");
var gameState = new State_1.default({
    win: 0,
    coin: 100,
    get: 0
});
window['gs'] = gameState;
exports.default = gameState;

cc._RF.pop();