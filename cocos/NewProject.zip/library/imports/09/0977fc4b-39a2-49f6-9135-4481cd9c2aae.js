"use strict";
cc._RF.push(module, '0977fxLOaJJ9pE1RIHNnCqu', 'State');
// scripts/State.ts

"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
var State = /** @class */ (function () {
    function State(initStates) {
        if (initStates === void 0) { initStates = {}; }
        this._states = {};
        this._events = {};
        this._states = __assign({}, initStates);
        for (var key in initStates) {
            this._events[key] = [];
        }
    }
    State.prototype.isExist = function (key) {
        if (!Reflect.has(this._states, key)) {
            this._states[key] = 0;
            this._events[key] = [];
        }
    };
    State.prototype.get = function (key) {
        this.isExist(key);
        return this._states[key];
    };
    State.prototype.set = function (key, value) {
        this.isExist(key);
        this._states[key] = value;
        this.cast(key);
    };
    State.prototype.add = function (key, value) {
        this.isExist(key);
        this._states[key] += value;
        this.cast(key);
    };
    State.prototype.inc = function (key) {
        this.add(key, 1);
    };
    State.prototype.dec = function (key) {
        this.add(key, -1);
    };
    State.prototype.listen = function (key, obj, callback) {
        this.isExist(key);
        this._events[key].push({
            obj: obj,
            callback: callback
        });
        this.cast(key);
    };
    State.prototype.delisten = function (key, obj) {
        var index = this._events[key].findIndex(function (e) { return e.obj === obj; });
        this._events[key].splice(index, 1);
    };
    //广播
    State.prototype.cast = function (key) {
        this.isExist(key);
        if (this._events[key] instanceof Array) {
            for (var _i = 0, _a = this._events[key]; _i < _a.length; _i++) {
                var _b = _a[_i], obj = _b.obj, callback = _b.callback;
                callback.call(obj);
            }
        }
    };
    State.prototype.clean = function () {
        for (var key in this._states) {
            this._states[key] = 0;
            this.cast(key);
        }
    };
    return State;
}());
exports.default = State;

cc._RF.pop();