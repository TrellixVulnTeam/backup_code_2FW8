"use strict";
cc._RF.push(module, '4f87cTiXhtFzaJRJenrgbMA', 'WagerState');
// scripts/WagerState.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var State_1 = require("./State");
var wagerState = new State_1.default();
exports.default = wagerState;

cc._RF.pop();