"use strict";
cc._RF.push(module, '0a7aef/GiJL8KHUkAxXGs0T', 'ScoreMap');
// scripts/ScoreMap.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    'bar': 120,
    '77': 40,
    'star': 30,
    'watermelon': 20,
    'mongo': 20,
    'ring': 15,
    'lemon': 10,
    'orange': 10,
    'apple': 5,
    'goodlucky': 200
};

cc._RF.pop();