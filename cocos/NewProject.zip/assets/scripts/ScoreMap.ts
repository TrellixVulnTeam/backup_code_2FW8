export default {
  'bar': 120,
  '77': 40,
  'star': 30,
  'watermelon': 20,
  'mongo': 20,
  'ring': 15,
  'lemon': 10,
  'orange': 10,
  'apple': 5,
  'goodlucky': 200
}