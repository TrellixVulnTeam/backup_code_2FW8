import State from "./State";

const wagerState = new State();
export default wagerState;