export default [
  {
    x: 1,
    y: 0,
    item: 'ring',
  },
  {
    item: 'bar', 
    count:50,
  },
  {
    item: 'bar', 
    count: 120
  },
  {
    item: 'apple',
  },
  {
    item: 'apple',
    count: 3
  },
  {
    item: 'mongo',
  },
  {
    item: 'watermelon',
    x: 0,
    y: -1,
  },
  {
    item: 'watermelon',
    count: 3
  },
  {
    item: 'goodlucky',
  },
  {
    item: 'apple',
  },
  {
    item: 'orange',
    count: 3
  },
  {
    item: 'orange',
  },
  {
    x: -1,
    y: 0,
    item: 'ring'
  },
  {
    item: '77',
    count: 3
  },
  {
    item: '77',
  },
  {
    item: 'apple',
  },
  {
    item: 'mongo',
    count: 3,
  },
  {
    item: 'mongo',
  },
  {
    item: "star",
    x: 0,
    y: 1
  },
  {
    item: "star",
    count: 3
  },
  {
    item: 'goodlucky',
  },
  {
    item: 'apple',
  },
  {
    item: "ring",
    count: 3
  },
  {
    item: "orange",
  },
]