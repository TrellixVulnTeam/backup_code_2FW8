
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/State.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '0977fxLOaJJ9pE1RIHNnCqu', 'State');
// scripts/State.ts

"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
var State = /** @class */ (function () {
    function State(initStates) {
        if (initStates === void 0) { initStates = {}; }
        this._states = {};
        this._events = {};
        this._states = __assign({}, initStates);
        for (var key in initStates) {
            this._events[key] = [];
        }
    }
    State.prototype.isExist = function (key) {
        if (!Reflect.has(this._states, key)) {
            this._states[key] = 0;
            this._events[key] = [];
        }
    };
    State.prototype.get = function (key) {
        this.isExist(key);
        return this._states[key];
    };
    State.prototype.set = function (key, value) {
        this.isExist(key);
        this._states[key] = value;
        this.cast(key);
    };
    State.prototype.add = function (key, value) {
        this.isExist(key);
        this._states[key] += value;
        this.cast(key);
    };
    State.prototype.inc = function (key) {
        this.add(key, 1);
    };
    State.prototype.dec = function (key) {
        this.add(key, -1);
    };
    State.prototype.listen = function (key, obj, callback) {
        this.isExist(key);
        this._events[key].push({
            obj: obj,
            callback: callback
        });
        this.cast(key);
    };
    State.prototype.delisten = function (key, obj) {
        var index = this._events[key].findIndex(function (e) { return e.obj === obj; });
        this._events[key].splice(index, 1);
    };
    //广播
    State.prototype.cast = function (key) {
        this.isExist(key);
        if (this._events[key] instanceof Array) {
            for (var _i = 0, _a = this._events[key]; _i < _a.length; _i++) {
                var _b = _a[_i], obj = _b.obj, callback = _b.callback;
                callback.call(obj);
            }
        }
    };
    State.prototype.clean = function () {
        for (var key in this._states) {
            this._states[key] = 0;
            this.cast(key);
        }
    };
    return State;
}());
exports.default = State;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcU3RhdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0lBSUUsZUFBWSxVQUFlO1FBQWYsMkJBQUEsRUFBQSxlQUFlO1FBSDNCLFlBQU8sR0FBVyxFQUFFLENBQUM7UUFDckIsWUFBTyxHQUFXLEVBQUUsQ0FBQztRQUduQixJQUFJLENBQUMsT0FBTyxnQkFBUSxVQUFVLENBQUUsQ0FBQztRQUVqQyxLQUFLLElBQUksR0FBRyxJQUFJLFVBQVUsRUFBRTtZQUMxQixJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQTtTQUN2QjtJQUVILENBQUM7SUFDTyx1QkFBTyxHQUFmLFVBQWdCLEdBQUc7UUFDakIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsRUFBRTtZQUNuQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN0QixJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztTQUN4QjtJQUNILENBQUM7SUFFRCxtQkFBRyxHQUFILFVBQUksR0FBVztRQUNiLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDbEIsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQzNCLENBQUM7SUFFRCxtQkFBRyxHQUFILFVBQUksR0FBVyxFQUFFLEtBQWE7UUFDNUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNsQixJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQztRQUMxQixJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ2pCLENBQUM7SUFFRCxtQkFBRyxHQUFILFVBQUksR0FBVyxFQUFFLEtBQWE7UUFDNUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNsQixJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEtBQUssQ0FBQztRQUMzQixJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ2pCLENBQUM7SUFFRCxtQkFBRyxHQUFILFVBQUksR0FBVztRQUNiLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ25CLENBQUM7SUFFRCxtQkFBRyxHQUFILFVBQUksR0FBVztRQUNiLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDcEIsQ0FBQztJQUVELHNCQUFNLEdBQU4sVUFBTyxHQUFXLEVBQUUsR0FBRyxFQUFFLFFBQVE7UUFDL0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNsQixJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNyQixHQUFHLEtBQUE7WUFDSCxRQUFRLFVBQUE7U0FDVCxDQUFDLENBQUE7UUFFRixJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0lBQ2hCLENBQUM7SUFFRCx3QkFBUSxHQUFSLFVBQVMsR0FBVyxFQUFFLEdBQUc7UUFDdkIsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBQSxDQUFDLElBQUksT0FBQSxDQUFDLENBQUMsR0FBRyxLQUFLLEdBQUcsRUFBYixDQUFhLENBQUMsQ0FBQTtRQUMzRCxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUE7SUFDcEMsQ0FBQztJQUVELElBQUk7SUFDSixvQkFBSSxHQUFKLFVBQUssR0FBVztRQUNkLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDbEIsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZLEtBQUssRUFBRTtZQUN0QyxLQUE4QixVQUFpQixFQUFqQixLQUFBLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQWpCLGNBQWlCLEVBQWpCLElBQWlCLEVBQUU7Z0JBQXhDLElBQUEsV0FBaUIsRUFBZixZQUFHLEVBQUUsc0JBQVE7Z0JBQ3RCLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7YUFDbkI7U0FDRjtJQUNILENBQUM7SUFFRCxxQkFBSyxHQUFMO1FBQ0UsS0FBSyxJQUFJLEdBQUcsSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQzVCLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3RCLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDaEI7SUFDSCxDQUFDO0lBQ0gsWUFBQztBQUFELENBM0VBLEFBMkVDLElBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBjbGFzcyBTdGF0ZSB7XHJcbiAgX3N0YXRlczogT2JqZWN0ID0ge307XHJcbiAgX2V2ZW50czogT2JqZWN0ID0ge307XHJcblxyXG4gIGNvbnN0cnVjdG9yKGluaXRTdGF0ZXMgPSB7fSkge1xyXG4gICAgdGhpcy5fc3RhdGVzID0geyAuLi5pbml0U3RhdGVzIH07XHJcblxyXG4gICAgZm9yIChsZXQga2V5IGluIGluaXRTdGF0ZXMpIHtcclxuICAgICAgdGhpcy5fZXZlbnRzW2tleV0gPSBbXVxyXG4gICAgfVxyXG5cclxuICB9XHJcbiAgcHJpdmF0ZSBpc0V4aXN0KGtleSkge1xyXG4gICAgaWYgKCFSZWZsZWN0Lmhhcyh0aGlzLl9zdGF0ZXMsIGtleSkpIHtcclxuICAgICAgdGhpcy5fc3RhdGVzW2tleV0gPSAwO1xyXG4gICAgICB0aGlzLl9ldmVudHNba2V5XSA9IFtdO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZ2V0KGtleTogc3RyaW5nKSB7XHJcbiAgICB0aGlzLmlzRXhpc3Qoa2V5KTtcclxuICAgIHJldHVybiB0aGlzLl9zdGF0ZXNba2V5XTtcclxuICB9XHJcblxyXG4gIHNldChrZXk6IHN0cmluZywgdmFsdWU6IG51bWJlcikge1xyXG4gICAgdGhpcy5pc0V4aXN0KGtleSk7XHJcbiAgICB0aGlzLl9zdGF0ZXNba2V5XSA9IHZhbHVlO1xyXG4gICAgdGhpcy5jYXN0KGtleSk7XHJcbiAgfVxyXG5cclxuICBhZGQoa2V5OiBzdHJpbmcsIHZhbHVlOiBudW1iZXIpIHtcclxuICAgIHRoaXMuaXNFeGlzdChrZXkpO1xyXG4gICAgdGhpcy5fc3RhdGVzW2tleV0gKz0gdmFsdWU7XHJcbiAgICB0aGlzLmNhc3Qoa2V5KTtcclxuICB9XHJcblxyXG4gIGluYyhrZXk6IHN0cmluZykge1xyXG4gICAgdGhpcy5hZGQoa2V5LCAxKTtcclxuICB9XHJcblxyXG4gIGRlYyhrZXk6IHN0cmluZykge1xyXG4gICAgdGhpcy5hZGQoa2V5LCAtMSk7XHJcbiAgfVxyXG5cclxuICBsaXN0ZW4oa2V5OiBzdHJpbmcsIG9iaiwgY2FsbGJhY2spIHtcclxuICAgIHRoaXMuaXNFeGlzdChrZXkpO1xyXG4gICAgdGhpcy5fZXZlbnRzW2tleV0ucHVzaCh7XHJcbiAgICAgIG9iaixcclxuICAgICAgY2FsbGJhY2tcclxuICAgIH0pXHJcblxyXG4gICAgdGhpcy5jYXN0KGtleSlcclxuICB9XHJcblxyXG4gIGRlbGlzdGVuKGtleTogc3RyaW5nLCBvYmopIHtcclxuICAgIGxldCBpbmRleCA9IHRoaXMuX2V2ZW50c1trZXldLmZpbmRJbmRleChlID0+IGUub2JqID09PSBvYmopXHJcbiAgICB0aGlzLl9ldmVudHNba2V5XS5zcGxpY2UoaW5kZXgsIDEpXHJcbiAgfVxyXG5cclxuICAvL+W5v+aSrVxyXG4gIGNhc3Qoa2V5OiBzdHJpbmcpIHtcclxuICAgIHRoaXMuaXNFeGlzdChrZXkpO1xyXG4gICAgaWYgKHRoaXMuX2V2ZW50c1trZXldIGluc3RhbmNlb2YgQXJyYXkpIHtcclxuICAgICAgZm9yIChsZXQgeyBvYmosIGNhbGxiYWNrIH0gb2YgdGhpcy5fZXZlbnRzW2tleV0pIHtcclxuICAgICAgICBjYWxsYmFjay5jYWxsKG9iailcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY2xlYW4oKSB7XHJcbiAgICBmb3IgKGxldCBrZXkgaW4gdGhpcy5fc3RhdGVzKSB7XHJcbiAgICAgIHRoaXMuX3N0YXRlc1trZXldID0gMDtcclxuICAgICAgdGhpcy5jYXN0KGtleSk7XHJcbiAgICB9XHJcbiAgfVxyXG59Il19