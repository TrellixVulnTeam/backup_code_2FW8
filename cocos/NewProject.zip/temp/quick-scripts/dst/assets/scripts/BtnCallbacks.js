
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/BtnCallbacks.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b7faavtW3RPCo6evqZ+YG89', 'BtnCallbacks');
// scripts/BtnCallbacks.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var WagerState_1 = require("./WagerState");
var GameState_1 = require("./GameState");
// Learn TypeScript:
//  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var BtnCallbacks = /** @class */ (function (_super) {
    __extends(BtnCallbacks, _super);
    function BtnCallbacks() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    BtnCallbacks_1 = BtnCallbacks;
    BtnCallbacks.prototype.IncWager = function (item) {
        this.AddWager(item, 1);
    };
    BtnCallbacks.prototype.AddWager = function (item, value) {
        if (GameState_1.default.get('coin') >= value) {
            WagerState_1.default.add(item, value);
            GameState_1.default.add('coin', -value * BtnCallbacks_1.mp);
        }
    };
    //每一项+1
    BtnCallbacks.prototype.AllPlusOne = function () {
        var _this = this;
        BtnCallbacks_1.allWagers.forEach(function (key) {
            _this.IncWager(key);
        });
    };
    //投注减半
    BtnCallbacks.prototype.RecuceHalfWager = function () {
        var _this = this;
        BtnCallbacks_1.allWagers.forEach(function (key) {
            var halfCount = Math.floor(WagerState_1.default.get(key) / 2);
            if (WagerState_1.default.get(key) === 1) {
                halfCount = 1;
            }
            _this.AddWager(key, -halfCount);
        });
    };
    //投注加倍
    BtnCallbacks.prototype.DoubleWager = function () {
        var _this = this;
        BtnCallbacks_1.allWagers.forEach(function (key) {
            var count = WagerState_1.default.get(key);
            _this.AddWager(key, count);
        });
    };
    //重置所有状态
    BtnCallbacks.prototype.Reset = function () {
        if (GameState_1.default.get('coin') <= 0) {
            WagerState_1.default.clean();
            GameState_1.default.clean();
            GameState_1.default.set('coin', 100);
        }
    };
    var BtnCallbacks_1;
    BtnCallbacks.allWagers = ['apple', 'orange', 'mongo', 'ring', 'watermelon', '77', 'star', 'bar'];
    BtnCallbacks.mp = 10;
    BtnCallbacks = BtnCallbacks_1 = __decorate([
        ccclass
    ], BtnCallbacks);
    return BtnCallbacks;
}(cc.Component));
exports.default = BtnCallbacks;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcQnRuQ2FsbGJhY2tzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDJDQUFzQztBQUN0Qyx5Q0FBb0M7QUFFcEMsb0JBQW9CO0FBQ3BCLHdFQUF3RTtBQUN4RSxtQkFBbUI7QUFDbkIsa0ZBQWtGO0FBQ2xGLDhCQUE4QjtBQUM5QixrRkFBa0Y7QUFFNUUsSUFBQSxrQkFBcUMsRUFBbkMsb0JBQU8sRUFBRSxzQkFBMEIsQ0FBQztBQUc1QztJQUEwQyxnQ0FBWTtJQUF0RDs7SUFrREEsQ0FBQztxQkFsRG9CLFlBQVk7SUFHckIsK0JBQVEsR0FBaEIsVUFBaUIsSUFBSTtRQUNqQixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQTtJQUMxQixDQUFDO0lBRU8sK0JBQVEsR0FBaEIsVUFBaUIsSUFBSSxFQUFFLEtBQUs7UUFDeEIsSUFBSSxtQkFBUyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLEVBQUU7WUFDaEMsb0JBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzVCLG1CQUFTLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxDQUFDLEtBQUssR0FBRyxjQUFZLENBQUMsRUFBRSxDQUFDLENBQUE7U0FDbEQ7SUFDTCxDQUFDO0lBRUQsT0FBTztJQUNBLGlDQUFVLEdBQWpCO1FBQUEsaUJBSUM7UUFIRyxjQUFZLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxVQUFBLEdBQUc7WUFDOUIsS0FBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN2QixDQUFDLENBQUMsQ0FBQTtJQUNOLENBQUM7SUFFRCxNQUFNO0lBQ0Msc0NBQWUsR0FBdEI7UUFBQSxpQkFRQztRQVBHLGNBQVksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFVBQUEsR0FBRztZQUM5QixJQUFJLFNBQVMsR0FBVSxJQUFJLENBQUMsS0FBSyxDQUFDLG9CQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQzNELElBQUksb0JBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUMzQixTQUFTLEdBQUcsQ0FBQyxDQUFBO2FBQ2hCO1lBQ0QsS0FBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNuQyxDQUFDLENBQUMsQ0FBQTtJQUNOLENBQUM7SUFFRCxNQUFNO0lBQ0Msa0NBQVcsR0FBbEI7UUFBQSxpQkFLQztRQUpHLGNBQVksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFVBQUEsR0FBRztZQUM5QixJQUFJLEtBQUssR0FBVSxvQkFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUN2QyxLQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUM5QixDQUFDLENBQUMsQ0FBQTtJQUNOLENBQUM7SUFFRCxRQUFRO0lBQ0QsNEJBQUssR0FBWjtRQUNJLElBQUksbUJBQVMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzVCLG9CQUFVLENBQUMsS0FBSyxFQUFFLENBQUE7WUFDbEIsbUJBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQTtZQUNqQixtQkFBUyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUE7U0FDN0I7SUFDTCxDQUFDOztJQTlDTSxzQkFBUyxHQUFrQixDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBQyxZQUFZLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQTtJQUNqRyxlQUFFLEdBQVUsRUFBRSxDQUFBO0lBRkosWUFBWTtRQURoQyxPQUFPO09BQ2EsWUFBWSxDQWtEaEM7SUFBRCxtQkFBQztDQWxERCxBQWtEQyxDQWxEeUMsRUFBRSxDQUFDLFNBQVMsR0FrRHJEO2tCQWxEb0IsWUFBWSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB3YWdlclN0YXRlIGZyb20gXCIuL1dhZ2VyU3RhdGVcIjtcclxuaW1wb3J0IGdhbWVTdGF0ZSBmcm9tIFwiLi9HYW1lU3RhdGVcIjtcclxuXHJcbi8vIExlYXJuIFR5cGVTY3JpcHQ6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3R5cGVzY3JpcHQuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IGNjLl9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBCdG5DYWxsYmFja3MgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xyXG4gICAgc3RhdGljIGFsbFdhZ2VyczpBcnJheTxzdHJpbmc+ID0gIFsnYXBwbGUnLCAnb3JhbmdlJywgJ21vbmdvJywgJ3JpbmcnLCd3YXRlcm1lbG9uJywgJzc3JywgJ3N0YXInLCAnYmFyJ11cclxuICAgIHN0YXRpYyBtcDpudW1iZXIgPSAxMFxyXG4gICAgcHJpdmF0ZSBJbmNXYWdlcihpdGVtKSB7XHJcbiAgICAgICAgdGhpcy5BZGRXYWdlcihpdGVtLCAxKVxyXG4gICAgfVxyXG5cclxuICAgIHByaXZhdGUgQWRkV2FnZXIoaXRlbSwgdmFsdWUpIHtcclxuICAgICAgICBpZiAoZ2FtZVN0YXRlLmdldCgnY29pbicpID49IHZhbHVlKSB7XHJcbiAgICAgICAgICAgIHdhZ2VyU3RhdGUuYWRkKGl0ZW0sIHZhbHVlKTtcclxuICAgICAgICAgICAgZ2FtZVN0YXRlLmFkZCgnY29pbicsIC12YWx1ZSAqIEJ0bkNhbGxiYWNrcy5tcClcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLy/mr4/kuIDpobkrMVxyXG4gICAgcHVibGljIEFsbFBsdXNPbmUoKSB7XHJcbiAgICAgICAgQnRuQ2FsbGJhY2tzLmFsbFdhZ2Vycy5mb3JFYWNoKGtleSA9PiB7XHJcbiAgICAgICAgICAgIHRoaXMuSW5jV2FnZXIoa2V5KTtcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG5cclxuICAgIC8v5oqV5rOo5YeP5Y2KXHJcbiAgICBwdWJsaWMgUmVjdWNlSGFsZldhZ2VyKCkge1xyXG4gICAgICAgIEJ0bkNhbGxiYWNrcy5hbGxXYWdlcnMuZm9yRWFjaChrZXkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgaGFsZkNvdW50Om51bWJlciA9IE1hdGguZmxvb3Iod2FnZXJTdGF0ZS5nZXQoa2V5KSAvIDIpO1xyXG4gICAgICAgICAgICBpZiAod2FnZXJTdGF0ZS5nZXQoa2V5KSA9PT0gMSkge1xyXG4gICAgICAgICAgICAgICAgaGFsZkNvdW50ID0gMVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuQWRkV2FnZXIoa2V5LCAtaGFsZkNvdW50KTtcclxuICAgICAgICB9KVxyXG4gICAgfVxyXG5cclxuICAgIC8v5oqV5rOo5Yqg5YCNXHJcbiAgICBwdWJsaWMgRG91YmxlV2FnZXIoKSB7XHJcbiAgICAgICAgQnRuQ2FsbGJhY2tzLmFsbFdhZ2Vycy5mb3JFYWNoKGtleSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBjb3VudDpudW1iZXIgPSB3YWdlclN0YXRlLmdldChrZXkpO1xyXG4gICAgICAgICAgICB0aGlzLkFkZFdhZ2VyKGtleSwgY291bnQpO1xyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcblxyXG4gICAgLy/ph43nva7miYDmnInnirbmgIFcclxuICAgIHB1YmxpYyBSZXNldCgpIHtcclxuICAgICAgICBpZiAoZ2FtZVN0YXRlLmdldCgnY29pbicpIDw9IDApIHtcclxuICAgICAgICAgICAgd2FnZXJTdGF0ZS5jbGVhbigpXHJcbiAgICAgICAgICAgIGdhbWVTdGF0ZS5jbGVhbigpXHJcbiAgICAgICAgICAgIGdhbWVTdGF0ZS5zZXQoJ2NvaW4nLCAxMDApXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9XHJcbn1cclxuIl19