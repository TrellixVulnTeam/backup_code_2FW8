
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/GameState.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'c0a7dK4vENLe7Ppd9BOlK+d', 'GameState');
// scripts/GameState.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var State_1 = require("./State");
var gameState = new State_1.default({
    win: 0,
    coin: 100,
    get: 0
});
window['gs'] = gameState;
exports.default = gameState;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcR2FtZVN0YXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsaUNBQTRCO0FBRTVCLElBQU0sU0FBUyxHQUFHLElBQUksZUFBSyxDQUFDO0lBQzFCLEdBQUcsRUFBRSxDQUFDO0lBQ04sSUFBSSxFQUFFLEdBQUc7SUFDVCxHQUFHLEVBQUUsQ0FBQztDQUNQLENBQUMsQ0FBQztBQUNILE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxTQUFTLENBQUM7QUFDekIsa0JBQWUsU0FBUyxDQUFDIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFN0YXRlIGZyb20gXCIuL1N0YXRlXCI7XHJcblxyXG5jb25zdCBnYW1lU3RhdGUgPSBuZXcgU3RhdGUoe1xyXG4gIHdpbjogMCxcclxuICBjb2luOiAxMDAsXHJcbiAgZ2V0OiAwXHJcbn0pO1xyXG53aW5kb3dbJ2dzJ10gPSBnYW1lU3RhdGU7XHJcbmV4cG9ydCBkZWZhdWx0IGdhbWVTdGF0ZTsiXX0=