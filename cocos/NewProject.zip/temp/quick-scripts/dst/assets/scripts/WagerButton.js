
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/WagerButton.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'fbbd9CstH5A6qEyJymxcz6X', 'WagerButton');
// scripts/WagerButton.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var WagerState_1 = require("./WagerState");
var GameState_1 = require("./GameState");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var WagerButton = /** @class */ (function (_super) {
    __extends(WagerButton, _super);
    function WagerButton() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.item = "";
        return _this;
    }
    WagerButton.prototype.onLoad = function () {
        var button = this.node.getComponent(cc.Button);
        var clickEventHandler = new cc.Component.EventHandler();
        clickEventHandler.target = this.node; // 这个 node 节点是你的事件处理代码组件所属的节点
        clickEventHandler.component = "WagerButton"; // 这个是代码文件名
        clickEventHandler.handler = "callback";
        clickEventHandler.customEventData = "foobar";
        button.clickEvents.push(clickEventHandler);
    };
    WagerButton.prototype.callback = function (event, customEventData) {
        if (GameState_1.default.get('coin') > 0) {
            WagerState_1.default.add(this.item, 1);
            GameState_1.default.add('coin', -10);
        }
    };
    __decorate([
        property
    ], WagerButton.prototype, "item", void 0);
    WagerButton = __decorate([
        ccclass
    ], WagerButton);
    return WagerButton;
}(cc.Component));
exports.default = WagerButton;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcV2FnZXJCdXR0b24udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsMkNBQXNDO0FBQ3RDLHlDQUFvQztBQUU5QixJQUFBLGtCQUFxQyxFQUFuQyxvQkFBTyxFQUFFLHNCQUEwQixDQUFDO0FBRzVDO0lBQXlDLCtCQUFZO0lBRHJEO1FBQUEscUVBdUJDO1FBcEJDLFVBQUksR0FBVyxFQUFFLENBQUM7O0lBb0JwQixDQUFDO0lBbEJDLDRCQUFNLEdBQU47UUFDRSxJQUFJLE1BQU0sR0FBYyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFMUQsSUFBSSxpQkFBaUIsR0FBRyxJQUFJLEVBQUUsQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDeEQsaUJBQWlCLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyw2QkFBNkI7UUFDbkUsaUJBQWlCLENBQUMsU0FBUyxHQUFHLGFBQWEsQ0FBQyxDQUFBLFdBQVc7UUFDdkQsaUJBQWlCLENBQUMsT0FBTyxHQUFHLFVBQVUsQ0FBQztRQUN2QyxpQkFBaUIsQ0FBQyxlQUFlLEdBQUcsUUFBUSxDQUFDO1FBRTdDLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7SUFDN0MsQ0FBQztJQUVELDhCQUFRLEdBQVIsVUFBUyxLQUFLLEVBQUUsZUFBZTtRQUM3QixJQUFJLG1CQUFTLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUM3QixvQkFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzdCLG1CQUFTLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQzVCO0lBQ0gsQ0FBQztJQW5CRDtRQURDLFFBQVE7NkNBQ1M7SUFGQyxXQUFXO1FBRC9CLE9BQU87T0FDYSxXQUFXLENBc0IvQjtJQUFELGtCQUFDO0NBdEJELEFBc0JDLENBdEJ3QyxFQUFFLENBQUMsU0FBUyxHQXNCcEQ7a0JBdEJvQixXQUFXIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFdhZ2VyU3RhdGUgZnJvbSBcIi4vV2FnZXJTdGF0ZVwiO1xyXG5pbXBvcnQgZ2FtZVN0YXRlIGZyb20gXCIuL0dhbWVTdGF0ZVwiO1xyXG5cclxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcclxuXHJcbkBjY2NsYXNzXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFdhZ2VyQnV0dG9uIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcclxuICBAcHJvcGVydHlcclxuICBpdGVtOiBzdHJpbmcgPSBcIlwiO1xyXG5cclxuICBvbkxvYWQoKSB7XHJcbiAgICBsZXQgYnV0dG9uOiBjYy5CdXR0b24gPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbik7XHJcblxyXG4gICAgbGV0IGNsaWNrRXZlbnRIYW5kbGVyID0gbmV3IGNjLkNvbXBvbmVudC5FdmVudEhhbmRsZXIoKTtcclxuICAgIGNsaWNrRXZlbnRIYW5kbGVyLnRhcmdldCA9IHRoaXMubm9kZTsgLy8g6L+Z5LiqIG5vZGUg6IqC54K55piv5L2g55qE5LqL5Lu25aSE55CG5Luj56CB57uE5Lu25omA5bGe55qE6IqC54K5XHJcbiAgICBjbGlja0V2ZW50SGFuZGxlci5jb21wb25lbnQgPSBcIldhZ2VyQnV0dG9uXCI7Ly8g6L+Z5Liq5piv5Luj56CB5paH5Lu25ZCNXHJcbiAgICBjbGlja0V2ZW50SGFuZGxlci5oYW5kbGVyID0gXCJjYWxsYmFja1wiO1xyXG4gICAgY2xpY2tFdmVudEhhbmRsZXIuY3VzdG9tRXZlbnREYXRhID0gXCJmb29iYXJcIjtcclxuXHJcbiAgICBidXR0b24uY2xpY2tFdmVudHMucHVzaChjbGlja0V2ZW50SGFuZGxlcik7XHJcbiAgfVxyXG5cclxuICBjYWxsYmFjayhldmVudCwgY3VzdG9tRXZlbnREYXRhKSB7XHJcbiAgICBpZiAoZ2FtZVN0YXRlLmdldCgnY29pbicpID4gMCkge1xyXG4gICAgICBXYWdlclN0YXRlLmFkZCh0aGlzLml0ZW0sIDEpO1xyXG4gICAgICBnYW1lU3RhdGUuYWRkKCdjb2luJywgLTEwKTtcclxuICAgIH1cclxuICB9XHJcbn0iXX0=