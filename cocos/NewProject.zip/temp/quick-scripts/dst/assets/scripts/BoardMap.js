
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/BoardMap.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd6e17q0/oJOSbGM/M6Pi+z4', 'BoardMap');
// scripts/BoardMap.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = [
    {
        x: 1,
        y: 0,
        item: 'ring',
    },
    {
        item: 'bar',
        count: 50,
    },
    {
        item: 'bar',
        count: 120
    },
    {
        item: 'apple',
    },
    {
        item: 'apple',
        count: 3
    },
    {
        item: 'mongo',
    },
    {
        item: 'watermelon',
        x: 0,
        y: -1,
    },
    {
        item: 'watermelon',
        count: 3
    },
    {
        item: 'goodlucky',
    },
    {
        item: 'apple',
    },
    {
        item: 'orange',
        count: 3
    },
    {
        item: 'orange',
    },
    {
        x: -1,
        y: 0,
        item: 'ring'
    },
    {
        item: '77',
        count: 3
    },
    {
        item: '77',
    },
    {
        item: 'apple',
    },
    {
        item: 'mongo',
        count: 3,
    },
    {
        item: 'mongo',
    },
    {
        item: "star",
        x: 0,
        y: 1
    },
    {
        item: "star",
        count: 3
    },
    {
        item: 'goodlucky',
    },
    {
        item: 'apple',
    },
    {
        item: "ring",
        count: 3
    },
    {
        item: "orange",
    },
];

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcQm9hcmRNYXAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxrQkFBZTtJQUNiO1FBQ0UsQ0FBQyxFQUFFLENBQUM7UUFDSixDQUFDLEVBQUUsQ0FBQztRQUNKLElBQUksRUFBRSxNQUFNO0tBQ2I7SUFDRDtRQUNFLElBQUksRUFBRSxLQUFLO1FBQ1gsS0FBSyxFQUFDLEVBQUU7S0FDVDtJQUNEO1FBQ0UsSUFBSSxFQUFFLEtBQUs7UUFDWCxLQUFLLEVBQUUsR0FBRztLQUNYO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsT0FBTztLQUNkO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsT0FBTztRQUNiLEtBQUssRUFBRSxDQUFDO0tBQ1Q7SUFDRDtRQUNFLElBQUksRUFBRSxPQUFPO0tBQ2Q7SUFDRDtRQUNFLElBQUksRUFBRSxZQUFZO1FBQ2xCLENBQUMsRUFBRSxDQUFDO1FBQ0osQ0FBQyxFQUFFLENBQUMsQ0FBQztLQUNOO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsWUFBWTtRQUNsQixLQUFLLEVBQUUsQ0FBQztLQUNUO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsV0FBVztLQUNsQjtJQUNEO1FBQ0UsSUFBSSxFQUFFLE9BQU87S0FDZDtJQUNEO1FBQ0UsSUFBSSxFQUFFLFFBQVE7UUFDZCxLQUFLLEVBQUUsQ0FBQztLQUNUO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsUUFBUTtLQUNmO0lBQ0Q7UUFDRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxFQUFFLENBQUM7UUFDSixJQUFJLEVBQUUsTUFBTTtLQUNiO0lBQ0Q7UUFDRSxJQUFJLEVBQUUsSUFBSTtRQUNWLEtBQUssRUFBRSxDQUFDO0tBQ1Q7SUFDRDtRQUNFLElBQUksRUFBRSxJQUFJO0tBQ1g7SUFDRDtRQUNFLElBQUksRUFBRSxPQUFPO0tBQ2Q7SUFDRDtRQUNFLElBQUksRUFBRSxPQUFPO1FBQ2IsS0FBSyxFQUFFLENBQUM7S0FDVDtJQUNEO1FBQ0UsSUFBSSxFQUFFLE9BQU87S0FDZDtJQUNEO1FBQ0UsSUFBSSxFQUFFLE1BQU07UUFDWixDQUFDLEVBQUUsQ0FBQztRQUNKLENBQUMsRUFBRSxDQUFDO0tBQ0w7SUFDRDtRQUNFLElBQUksRUFBRSxNQUFNO1FBQ1osS0FBSyxFQUFFLENBQUM7S0FDVDtJQUNEO1FBQ0UsSUFBSSxFQUFFLFdBQVc7S0FDbEI7SUFDRDtRQUNFLElBQUksRUFBRSxPQUFPO0tBQ2Q7SUFDRDtRQUNFLElBQUksRUFBRSxNQUFNO1FBQ1osS0FBSyxFQUFFLENBQUM7S0FDVDtJQUNEO1FBQ0UsSUFBSSxFQUFFLFFBQVE7S0FDZjtDQUNGLENBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBbXHJcbiAge1xyXG4gICAgeDogMSxcclxuICAgIHk6IDAsXHJcbiAgICBpdGVtOiAncmluZycsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpdGVtOiAnYmFyJywgXHJcbiAgICBjb3VudDo1MCxcclxuICB9LFxyXG4gIHtcclxuICAgIGl0ZW06ICdiYXInLCBcclxuICAgIGNvdW50OiAxMjBcclxuICB9LFxyXG4gIHtcclxuICAgIGl0ZW06ICdhcHBsZScsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpdGVtOiAnYXBwbGUnLFxyXG4gICAgY291bnQ6IDNcclxuICB9LFxyXG4gIHtcclxuICAgIGl0ZW06ICdtb25nbycsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpdGVtOiAnd2F0ZXJtZWxvbicsXHJcbiAgICB4OiAwLFxyXG4gICAgeTogLTEsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpdGVtOiAnd2F0ZXJtZWxvbicsXHJcbiAgICBjb3VudDogM1xyXG4gIH0sXHJcbiAge1xyXG4gICAgaXRlbTogJ2dvb2RsdWNreScsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpdGVtOiAnYXBwbGUnLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaXRlbTogJ29yYW5nZScsXHJcbiAgICBjb3VudDogM1xyXG4gIH0sXHJcbiAge1xyXG4gICAgaXRlbTogJ29yYW5nZScsXHJcbiAgfSxcclxuICB7XHJcbiAgICB4OiAtMSxcclxuICAgIHk6IDAsXHJcbiAgICBpdGVtOiAncmluZydcclxuICB9LFxyXG4gIHtcclxuICAgIGl0ZW06ICc3NycsXHJcbiAgICBjb3VudDogM1xyXG4gIH0sXHJcbiAge1xyXG4gICAgaXRlbTogJzc3JyxcclxuICB9LFxyXG4gIHtcclxuICAgIGl0ZW06ICdhcHBsZScsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpdGVtOiAnbW9uZ28nLFxyXG4gICAgY291bnQ6IDMsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpdGVtOiAnbW9uZ28nLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaXRlbTogXCJzdGFyXCIsXHJcbiAgICB4OiAwLFxyXG4gICAgeTogMVxyXG4gIH0sXHJcbiAge1xyXG4gICAgaXRlbTogXCJzdGFyXCIsXHJcbiAgICBjb3VudDogM1xyXG4gIH0sXHJcbiAge1xyXG4gICAgaXRlbTogJ2dvb2RsdWNreScsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpdGVtOiAnYXBwbGUnLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaXRlbTogXCJyaW5nXCIsXHJcbiAgICBjb3VudDogM1xyXG4gIH0sXHJcbiAge1xyXG4gICAgaXRlbTogXCJvcmFuZ2VcIixcclxuICB9LFxyXG5dIl19