
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/ScoreMap.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '0a7aef/GiJL8KHUkAxXGs0T', 'ScoreMap');
// scripts/ScoreMap.ts

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    'bar': 120,
    '77': 40,
    'star': 30,
    'watermelon': 20,
    'mongo': 20,
    'ring': 15,
    'lemon': 10,
    'orange': 10,
    'apple': 5,
    'goodlucky': 200
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcU2NvcmVNYXAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxrQkFBZTtJQUNiLEtBQUssRUFBRSxHQUFHO0lBQ1YsSUFBSSxFQUFFLEVBQUU7SUFDUixNQUFNLEVBQUUsRUFBRTtJQUNWLFlBQVksRUFBRSxFQUFFO0lBQ2hCLE9BQU8sRUFBRSxFQUFFO0lBQ1gsTUFBTSxFQUFFLEVBQUU7SUFDVixPQUFPLEVBQUUsRUFBRTtJQUNYLFFBQVEsRUFBRSxFQUFFO0lBQ1osT0FBTyxFQUFFLENBQUM7SUFDVixXQUFXLEVBQUUsR0FBRztDQUNqQixDQUFBIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQge1xyXG4gICdiYXInOiAxMjAsXHJcbiAgJzc3JzogNDAsXHJcbiAgJ3N0YXInOiAzMCxcclxuICAnd2F0ZXJtZWxvbic6IDIwLFxyXG4gICdtb25nbyc6IDIwLFxyXG4gICdyaW5nJzogMTUsXHJcbiAgJ2xlbW9uJzogMTAsXHJcbiAgJ29yYW5nZSc6IDEwLFxyXG4gICdhcHBsZSc6IDUsXHJcbiAgJ2dvb2RsdWNreSc6IDIwMFxyXG59Il19