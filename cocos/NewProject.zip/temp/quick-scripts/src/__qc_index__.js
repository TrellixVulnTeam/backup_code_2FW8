
require('./assets/scripts/Ads');
require('./assets/scripts/BoardMap');
require('./assets/scripts/BtnCallbacks');
require('./assets/scripts/ClickSoundPlay');
require('./assets/scripts/Cursor');
require('./assets/scripts/FlashRun');
require('./assets/scripts/GameState');
require('./assets/scripts/GameStateLabel');
require('./assets/scripts/ScoreMap');
require('./assets/scripts/State');
require('./assets/scripts/WagerButton');
require('./assets/scripts/WagerLabel');
require('./assets/scripts/WagerState');
