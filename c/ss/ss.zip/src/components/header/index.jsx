import React from 'react'
import ToolTabs from './ToolTabs'


export default function Header(props) {
  return (
    <div>
      <ToolTabs />
    </div>
  )
}