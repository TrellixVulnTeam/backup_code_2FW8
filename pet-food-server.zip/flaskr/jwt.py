from flask_jwt import JWT, jwt_required, current_identity
from .db import get_db
from werkzeug.security import safe_str_cmp


class User:
    def __init__(self, row):
        self.id = row['id']
        self.username = row['username']
        self.password = row['password']


def authenticate(username, password):
    db = get_db()
    c = db.cursor()
    print(username, password)
    c.execute(
        "SELECT id, username, password from user WHERE username = '{0}'".format(username))
    userRow = c.fetchone()
    print(userRow)
    c.close()
    if userRow:
        user = User(userRow)
        print(user)
        if user and safe_str_cmp(user.password.encode('utf-8'), password.encode('utf-8')):
            return user


def identity(payload):
    user_id = payload['identity']
    db = get_db()
    c = db.cursor()
    c.execute(
        "SELECT id, username, password from user WHERE id = {0}".format(user_id))
    userRow = c.fetchone()
    c.close()
    if userRow:
        user = User(userRow)
        return user
    return None


def init_jwt(app):
    JWT(app, authenticate, identity)
