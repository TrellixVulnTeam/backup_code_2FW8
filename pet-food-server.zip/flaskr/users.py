from flask import Blueprint, request, jsonify
from flask_jwt import JWT, jwt_required, current_identity
from .db import get_db
from .querys import insertUser, queryUserByUsername
from .utils import res_status
import json

r = Blueprint('user', __name__)


#token测试
@r.route('/p')
@jwt_required()
def protected():
    return '%s' % current_identity.username

#注册
@r.route('/register', methods=['POST'])
def register():
    username = request.json['username']
    password = request.json['password']
    user = queryUserByUsername(username)
    if not user:
        insertUser(username, password)
        return jsonify(res_status('ok'))
    else:
        return jsonify(res_status('already exists!'))

#获取信息
@r.route('/user')
@jwt_required()
def userinfo():
    return jsonify({
        'username': current_identity.username,
        'id': current_identity.id
    })

#auth 获取token令牌