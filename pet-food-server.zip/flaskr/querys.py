from .db import get_db


class Food():
    def __init__(self, row):
        self.id = row['id']
        self.title = row['title']
        self.content = row['content']
        self.author = row['username']
        self.author_id = row['author_id']

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'author': self.author,
            'author_id': self.author_id
        }


def query(callback):
    db = get_db()
    c = db.cursor()
    result = callback(c)
    c.close()
    db.commit()
    return result


def insertUser(username, password):
    def insert(c):
        c.execute("INSERT INTO user(username, password) VALUES (?, ?)",
                  (username, password))
    query(insert)


def queryUserByUsername(username):
    def select(c):
        c.execute(
            "SELECT id, username, password from user WHERE username = '{0}'".format(username))
        return c.fetchone()
    return query(select)


def queryFoods():
    def select(c):
        c.execute(
            "SELECT post.id, username, author_id, title, content FROM post JOIN user ON post.author_id = user.id")
        return c.fetchall()

    foods = [Food(row).to_dict() for row in query(select)]
    return foods

def getFoodById(id):
    def select(c):
        c.execute("SELECT post.id, username, author_id, title, content FROM post JOIN user ON post.author_id = user.id WHERE post.id={0}".format(id))
        return c.fetchone()
    food = query(select)
    return Food(food).to_dict()

def getFoodByUserId(id):
    def select(c):
        c.execute("SELECT post.id, username, author_id, title, content FROM post JOIN user ON post.author_id = user.id WHERE user.id={0}".format(id))
        return c.fetchall()
    foods = [Food(row).to_dict() for row in query(select)]
    return foods


def hasExistsFoodByUserId(id, user_id):
    def select(c):
        c.execute("SELECT id, author_id FROM post WHERE post.id = '{0}' and author_id = '{1}'".format(
            id, user_id))
        r = c.fetchone()
        return not not r

    return query(select)


def insertFood(author_id, title, content):
    def insert(c):
        c.execute("INSERT INTO post(title, content, author_id) VALUES(?, ?, ?)",
                  (title, content, author_id))
    return query(insert)

def updateFood(id, title, content):
    def insert(c):
        c.execute("UPDATE post SET title = '{0}', content='{1}' WHERE id = {2}".format(title, content, id))
    return query(insert)

def deleteFood(id):
    def insert(c):
        c.execute("DELETE FROM post WHERE id = {0}".format(id))
    return query(insert)

def searchFood(keyword):
    def select(c):
        c.execute("SELECT post.id, username, author_id, title, content FROM post JOIN user ON post.author_id = user.id WHERE title LIKE '%{0}%' OR content LIKE '%{0}%'".format(keyword))
        return c.fetchall()
    foods = [Food(row).to_dict() for row in query(select)]
    return foods