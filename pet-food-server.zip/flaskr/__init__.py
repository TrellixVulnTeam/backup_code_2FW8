from flask import Flask
from .jwt import init_jwt
from flask_cors import CORS
import datetime
def create_app():
    app = Flask(__name__)
    app.debug = True
    app.config['SECRET_KEY'] = 'super-secret'
    app.config['JWT_EXPIRATION_DELTA'] = datetime.timedelta(days=30)
    # existing code omitted

    from . import db
    db.init_app(app)
    init_jwt(app)
    CORS(app)

    return app
