from flask import Blueprint, request, jsonify
from flask_jwt import JWT, jwt_required, current_identity
from .db import get_db
from .utils import res_status
from .querys import insertFood, queryFoods, searchFood, hasExistsFoodByUserId, updateFood, deleteFood, getFoodById, getFoodByUserId
import json

r = Blueprint('food', __name__)

# 获取foods
@r.route('/foods', methods=['GET'])
def foods():
    return jsonify(queryFoods())

# 获取food
@r.route('/foods/<id>', methods=['GET'])
def food(id):
    return jsonify(getFoodById(id))

# 根据用户获取foods
@r.route('/foods/user/<id>', methods=['GET'])
def foodsbyauthorid(id):
    return jsonify(getFoodByUserId(id))

# 提交foods
@r.route('/foods', methods=['POST'])
@jwt_required()
def postFoods():
    title = request.json['title']
    content = request.json['content']
    user_id = current_identity.id
    insertFood(user_id, title, content)
    return jsonify(res_status('ok'))

# 更新foods
@r.route('/foods/update/<food_id>', methods=['POST'])
@jwt_required()
def putFoods(food_id):
    title = request.json['title']
    content = request.json['content']
    isExists = hasExistsFoodByUserId(food_id, current_identity.id)
    if isExists:
        updateFood(food_id, title, content)
        return jsonify(res_status('ok'))
    return jsonify(res_status('error'))
    return title

# 删除foods
@r.route('/foods/<food_id>', methods=['DELETE'])
@jwt_required()
def deleteFoods(food_id):
    is_exists = hasExistsFoodByUserId(food_id, current_identity.id)
    if is_exists:
        deleteFood(food_id)
        return jsonify(res_status('ok'))
    else:
        return jsonify(res_status('error'))


# 搜索foods
@r.route('/search/<keyword>')
def search(keyword):
    return jsonify(searchFood(keyword))
