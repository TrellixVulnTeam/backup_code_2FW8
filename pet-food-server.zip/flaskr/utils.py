def res_status(code):
    return {'status': code}
