from flask import (Flask)
from flaskr import (
  create_app,
  foods,
  users
)
app = create_app()
app.register_blueprint(foods.r)
app.register_blueprint(users.r)
