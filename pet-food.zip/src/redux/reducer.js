import { combineReducers } from "C:/Users/liiiv/AppData/Local/Microsoft/TypeScript/3.6/node_modules/redux";
import home from "../views/HomeRedux";
import detail from "../views/DetailRedux";
import accout from "../views/AccoutRedux"
import user from "../views/UserRedux";
import editor from "../views/EditRedux";

export default combineReducers({
  home,
  detail,
  accout,
  user,
  editor
});
