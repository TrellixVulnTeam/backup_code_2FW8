import { createStore, applyMiddleware } from "redux";
import createFetchMiddleware from "redux-composable-fetch"
import { composeWithDevTools } from 'redux-devtools-extension';
import reducer from "./reducer";

const FetchMiddleware = createFetchMiddleware()
const composeEnhancers = composeWithDevTools({})

/**
 * 解析带有response对象的中间件
 */
const responseMiddleware = ({ dispatch }) => next => action => {
  if (!action || !action.payload || !(action.payload instanceof Response)) {
    return next(action)
  }

  const { payload } = action
  return payload.json().then(d => {
    next({
      ...action,
      payload: d,
    })
  })
}

//多异步串联
const sequenceMiddleware = ({ dispatch }) => next => action => {
  if (!Array.isArray(action)) {
    return next(action)
  }

  return action.reduce((result, currAction) => {
    return result.then(() => {
      if (Array.isArray(currAction)) {
        return Promise.all(currAction.map(item => dispatch(item)))
      } else {
        return dispatch(currAction)
      }
    })
  }, Promise.resolve())
}

//添加token
const addTokenMiddleware = ({ dispatch }) => next => action => {
  const token = localStorage.getItem('token');
  if (Reflect.has(action, 'types') &&
    Reflect.has(action, 'url') &&
    action.types instanceof Array && token) {
    const { headers = {} } = action;
    next({
      ...action,
      headers: {
        ...headers,
        'Authorization': `JWT ${token}`
      }
    });
  } else {
    next(action);
  }
}

/**
*  处理action回调
*/
const handleCallback = ({ dispatch }) => next => action => {

  if (action.callback) {
    action.callback(action)
  }

  next({
    ...action
  })
}


export default function initStore() {
  return createStore(reducer,
    composeEnhancers(
      applyMiddleware(
        sequenceMiddleware,
        addTokenMiddleware,
        FetchMiddleware,
        responseMiddleware,
        handleCallback
      )
    )
  );
}
