import React from 'react';
import ReactDOM from 'react-dom';
import routes from './routes';
import configureStore from './redux/configureStore';
import { Provider } from 'react-redux';
import './index.css';
import { loadUser } from './components/User/UserInfoRedux';

const store = configureStore();
const token = localStorage.getItem('token');
if (token) {
  store.dispatch(loadUser());
}


ReactDOM.render((
  <Provider store={store}>
    <div style={{
      marginTop: 120
    }}>
      {routes}
    </div>
  </Provider>
), document.getElementById('root'));