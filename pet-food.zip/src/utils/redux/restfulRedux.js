export default (
  dataname,
  dval,
  loadHandle = (state, { payload }) => {
    return {
      ...state,
      isloading: false,
      error: false,
      [`${dataname}`]: loadHandle(payload),
    }
  }
) => (reducers) => {
  reducers.addInitState({
    [`${dataname}`]: dval,
    loading: false,
    error: false,
  });

  reducers.addReduce(`load_${dataname}`, (state, action) => {
    return {
      ...state,
      isloading: true,
      error: false,
    }
  });

  reducers.addReduce(`load_${dataname}_success`, loadHandle);

  reducers.addReduce(`load_${dataname}_error`, (state, action) => {
    return {
      ...state,
      isloading: true,
      error: false,
    }
  });

  return [
    `load_${dataname}`,
    `load_${dataname}_success`,
    `load_${dataname}_error`
  ];
}