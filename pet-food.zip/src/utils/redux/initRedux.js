export default (handlers, initialState) => (state = initialState, action) => {
  const { type } = action;
  
  if (Reflect.has(handlers, type)) {
    return handlers[type](state, action);
  }
  return state;
}