export default function () {
  let initState = {};
  const handlers = {};

  return {
    addInitState: (obj) => Object.assign(initState, obj),
    reducer: function (state = initialState, action) {
      const { type } = action;

      if (Reflect.has(handlers, type)) {
        return handlers[type](state, action);
      }
      return state;
    },
    addReduce(eventname, func) {
      handlers[eventname] = func;
    },
  }
}