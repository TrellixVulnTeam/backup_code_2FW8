import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import { useParams } from 'react-router-dom';
import DetailRedux, { detailAction } from './DetailRedux';
import DetailShow from '../components/Detail/DetailShow';
import DetailControl from '../components/Detail/DetailControl';

import { withRouter } from 'react-router';
import { Container } from '@material-ui/core';
function Detial({ detail, loadArticle, user, deleteArticle, history }) {
  const { id } = useParams();
  const { article } = detail.detail;
  useEffect(() => {
    loadArticle(id);
  }, []);

  const handleDeleteArticle = () => {
    if (!!article) {
      deleteArticle(article.id, () => {
        history.push('/')
      });
    }
  }

  const handleEditorArticle = () => {
    history.push(`/update/${id}`)
  }

  return (
    <Container maxWidth="sm">
      <DetailShow article={article} />
      <DetailControl
        style={{
          position: 'fixed',
          bottom: 0,
        }}
        control={article && user && article.author_id === user.id}
        onDelete={handleDeleteArticle}
        onEdit={handleEditorArticle} />
    </Container>
  );
}

export default withRouter(connect(state => ({
  detail: state.detail,
  user: state.user.info.user
}), {
  ...detailAction
})(Detial));