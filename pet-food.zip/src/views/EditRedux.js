import { combineReducers } from "redux";
import create from '../components/Edit/CreateRedux';
import * as createAction from '../components/Edit/CreateRedux';
import update from '../components/Edit/UpdateRedux';
import * as updateAction from '../components/Edit/UpdateRedux';
export {
  createAction,
  updateAction,
}

export default combineReducers({
  create,
  update
});
