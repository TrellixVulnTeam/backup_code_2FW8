import React, { useState, useEffect } from 'react';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import { Container, Card, Paper } from '@material-ui/core';
import FoodList from '../components/Home/FoodList';
import { infoAction, postAction } from './UserRedux';
import classes from './User.module.css'

function User({ history, user, list, loadUserPosts }) {

  useEffect(() => {
    if (user) {
      loadUserPosts(user.id);
    }
  }, [user]);

  const goClick = ({ id }) => {
    history.push(`/detail/${id}`);
  }

  if (!user) {
    return <></>
  }
  
  return (
    <Container maxWidth="sm">
      <div className={classes.box}>
        <Paper className={classes.user}>
          User Name: <strong>{user.username}</strong>
        </Paper>
      </div>
      <div className={classes.box}>
        {
          list.length > 0 ?
            <FoodList foods={list} onClick={goClick} /> :
            <Paper className={classes.null}>No Content</Paper>
        }
      </div>

    </Container>
  );
}

export default withRouter(connect(state => ({
  user: state.user.info.user,
  list: state.user.posts.list
}), {
  ...postAction
})(User));