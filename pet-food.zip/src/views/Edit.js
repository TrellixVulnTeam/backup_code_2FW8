import React, { useState, useEffect } from 'react';
import TitleEdit from '../components/Edit/TitleEdit';
import { Container, Fab, Dialog, DialogContent, CircularProgress, Button } from '@material-ui/core';
import { Publish } from '@material-ui/icons'
import classes from './Edit.module.css';
import ContentEdit from '../components/Edit/ContentEdit';
import { connect } from 'react-redux';
import { createAction, updateAction } from './EditRedux';
import { withRouter } from 'react-router';
import { useParams } from 'react-router-dom';

function LoadingAlert({ ...rest }) {
  return (
    <Dialog {...rest}>
      <DialogContent>
        <CircularProgress
          variant="determinate"
          value={100}
          size={24}
          thickness={4}
          style={{
            color: '#eef3fd',
          }}
        />
      </DialogContent>

    </Dialog>
  );
}

function Edit({
  publishArticle,
  publishDone,
  updateArticle,
  updateDone,
  create,
  update,
  article,
  history,
  match
}) {
  let { id = -1 } = useParams();

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [mode, setMode] = useState('create');
  const modes = { create, update };

  const getMode = () => modes[mode];

  const handlePublishArticle = () => {
    if (mode === 'update') {
      updateArticle(id, title, content);
    } else if (mode === 'create') {
      publishArticle(title, content);
    }
  };

  useEffect(() => {

    if (id > 0 && article) {
      const { title = '', content = '' } = article;
      setTitle(title);
      setContent(content);
      setMode('update');
    }
  }, [id]);

  useEffect(() => {
    if (getMode().done === true) {
      history.push('/');
      if (mode === 'update') {
        updateDone();
      } else if (mode === 'create') {
        publishDone();
      }
    }
  }, [create, update]);

  return (
    <Container maxWidth="sm" className={classes.root}>
      <TitleEdit className={classes.model} value={title} onChange={setTitle} />
      <ContentEdit
        placeholder="content"
        className={classes.model}
        value={content}
        onChange={setContent} />
      <Button color="primary" onClick={handlePublishArticle}>
        Publish
      </Button>
      <LoadingAlert open={create.loading} />
    </Container>
  )
};

export default withRouter(connect(state => ({
  create: state.editor.create,
  update: state.editor.update,
  article: state.detail.detail.article,
}), {
  ...createAction,
  ...updateAction,
})(Edit));