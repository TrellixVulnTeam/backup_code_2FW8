import { combineReducers } from "redux";
import list from '../components/Home/FoodListRedux';
import * as listAction from '../components/Home/FoodListRedux';

export {
  listAction,
}

export default combineReducers({
  list,
});
