import React from 'react';
import LoginForm from '../components/Login/LoginForm';
import { Paper, Container } from '@material-ui/core';
import { loginAction, registerAction } from './AccoutRedux';
import { infoAction } from './UserRedux'
import { connect } from 'react-redux';
import { withRouter } from 'react-router'

function Accout({ login, loadUser, register, history }) {

  const handleLogin = (username, password) => login({ username, password }, (action) => {
    if (!action.payload) return;
    const { access_token = "" } = action.payload;
    localStorage.setItem('token', access_token);
    loadUser(() => {
      history.push('/user');
    });
  });

  const handleRegister = (username, password) => register({username, password}, (action) => {
    if (!action.payload) return;
    history.push('/');
  })

  return (
    <Container maxWidth="sm">
      <Paper style={{
        margin: 10,
      }}>
        <LoginForm onLogin={handleLogin} onSignup={handleRegister} />
      </Paper>
    </Container>

  )
}

export default withRouter(connect(state => ({
  accout: state.accout,
  user: state.user.info.user
}), {
  ...loginAction,
  ...infoAction,
  ...registerAction,
})(Accout));