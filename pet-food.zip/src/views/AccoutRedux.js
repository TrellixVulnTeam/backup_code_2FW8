import { combineReducers } from "redux";
import login from '../components/Login/LoginFormRedux';
import * as loginAction from '../components/Login/LoginFormRedux';
import register from '../components/Login/RegisterRedux';
import * as registerAction from '../components/Login/RegisterRedux';
export {
  loginAction,
  registerAction,
}

export default combineReducers({
  login,
  register
});
