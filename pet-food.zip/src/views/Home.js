import React, { useEffect } from 'react';
import FoodList from '../components/Home/FoodList';
import { connect } from 'react-redux';
import { listAction } from './HomeRedux';
import { detailAction } from './DetailRedux';
import { Container } from '@material-ui/core';
import { withRouter } from 'react-router';
import AddFab from '../components/Common/AddFab';

function Home({ list, loadFood, setDetailData, history }) {
  useEffect(() => {
    loadFood()
  }, []);

  const goClick = ({ id }) => {
    history.push(`/detail/${id}`);
  }

  return (
    <Container maxWidth="sm">
      <FoodList foods={list.foods} onClick={goClick} />
      <AddFab onClick={() => history.push('/edit')} />
    </Container>
  )
}

export default withRouter(connect(state => ({
  list: state.home.list,
}), {
  ...listAction,
  ...detailAction
})(Home));