import { combineReducers } from "C:/Users/liiiv/AppData/Local/Microsoft/TypeScript/3.6/node_modules/redux";
import detail from '../components/Detail/DetailShowRedux';
import * as detailAction from '../components/Detail/DetailShowRedux';

export {
  detailAction,
}

export default combineReducers({
  detail,
});
