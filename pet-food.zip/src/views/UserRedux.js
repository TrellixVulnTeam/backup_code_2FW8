import { combineReducers } from "redux";
import info from "../components/User/UserInfoRedux";
import posts from "../components/User/UserPostsRedux";
import * as infoAction from "../components/User/UserInfoRedux";
import * as postAction from "../components/User/UserPostsRedux";

export {
  infoAction,
  postAction,
}

export default combineReducers({
  info,
  posts,
});
