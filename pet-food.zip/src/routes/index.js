import React from 'react';
import { BrowserRouter as Router, Switch, Route, Redirect } from 'react-router-dom';
import Home from '../views/Home';
import User from '../views/User';
import Detail from '../views/Detail';
import Header from '../components/Common/Header';
import Accout from '../views/Accout';
import Edit from '../views/Edit';
import PrivateRoute from './PrivateRoute';

export default (
  <Router>
    <Header />
    <Switch>
      <Route exact path="/">
        <Home />
      </Route>
      <Route path="/detail/:id">
        <Detail />
      </Route>
      <PrivateRoute path="/user" component={User} />
      <PrivateRoute path="/edit" component={Edit} />
      <PrivateRoute path="/update/:id" component={Edit} />
      <Route path="/login" render={() => {
        const token = localStorage.getItem('token');
        return (
          token ?
            <Redirect to="/" /> :
            <Accout />
        );
      }} />
    </Switch>
  </Router>
)