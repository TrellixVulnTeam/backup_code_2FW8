import React from 'react';
import { Dialog, DialogTitle, DialogContent, DialogActions, Button } from '@material-ui/core';

export default function ({ open = false, setOpen, onDelete }) {

  const handleClose = () => setOpen(false)
  const handleDelete = () => {
    onDelete();
    setOpen(false);
  }

  return (
    <Dialog
      open={open}
      onClose={handleClose}>
      <DialogTitle id="alert-dialog-title">{"Do you want to delete this pet recipe?"}</DialogTitle>
      <DialogActions>
        <Button onClick={handleClose} color="primary">
          No
          </Button>
        <Button onClick={handleDelete} color="primary" autoFocus>
          Delete
          </Button>
      </DialogActions>
    </Dialog>
  )

}