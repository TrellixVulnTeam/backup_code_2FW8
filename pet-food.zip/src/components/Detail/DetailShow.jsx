import React from 'react';
import { Paper, Typography, makeStyles } from '@material-ui/core';

const useStyles = makeStyles(theme => ({
  root: {
    padding: 10,
    margin: 10,
  },
}));

export default function ({ article }) {
  const classes = useStyles();
  if (!article) {
    return <></>;
  }

  return (
    <Paper className={classes.root}>
      <Typography variant="h4" component="h2">
        {article.title}
      </Typography>
      <Typography variant="h6" component="h6" style={{color: '#ccc'}}>
        author: {article.author}
      </Typography>
      <Typography component="p">
        {article.content}
      </Typography>
    </Paper>
  );
}