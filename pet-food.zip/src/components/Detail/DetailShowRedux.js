const initialState = {
  article: null,
  loading: false,
  error: false,
}

const LOAD_ARTICLE = 'load_article';
const LOAD_ARTICLE_SUCCESS = 'load_article_success';
const LOAD_ARTICLE_ERROR = 'load_article_error';

export function loadArticle(id, callback = () => {}) {
  return {
    types: [LOAD_ARTICLE, LOAD_ARTICLE_SUCCESS, LOAD_ARTICLE_ERROR],
    url: `http://localhost:5000/foods/${id}`,
    callback
  }
}


export function deleteArticle(post_id, callback = () => {}) {
  return {
    types: [LOAD_ARTICLE, LOAD_ARTICLE_SUCCESS, LOAD_ARTICLE_ERROR],
    url: `http://localhost:5000/foods/${post_id}`,
    method: 'DELETE',
    callback
  }
}

export default function (state = initialState, action) {
  const { type, payload } = action;
  if (type === LOAD_ARTICLE) {
    return {
      ...state,
      loading: true,
      error: false,
    }
  } else if (type === LOAD_ARTICLE_SUCCESS) {
    return {
      ...state,
      loading: true,
      error: false,
      article: payload,
    };
  } else if (type === LOAD_ARTICLE_ERROR) {
    return {
      ...state,
      loading: false,
      error: true
    }
  } else {
    return state;
  }
}