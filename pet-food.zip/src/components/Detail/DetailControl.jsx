import React from 'react';
import classes from './DetailControl.module.css';
import { IconButton } from '@material-ui/core';
import { Delete, Edit } from '@material-ui/icons'
import DeleteAlert from './DeleteAlert';

const nullCallback = () => { };
export default function ({
  onDelete = nullCallback,
  onEdit = nullCallback,
  id,
  control = false
}) {
  const [open, setOpen] = React.useState(false);
  const handleDelete = () => {
    setOpen(true);
  }
  
  const handleEdit = () => onEdit(id)

  if (!control) {
    return <></>
  }
  return (
    <div className={classes.root} >
      <IconButton className={classes.btn} onClick={handleDelete}>
        <Delete />
      </IconButton>
      <IconButton className={classes.btn} onClick={handleEdit}>
        <Edit />
      </IconButton>
      <DeleteAlert open={open} setOpen={setOpen} onDelete={onDelete} />
    </div>
  );
}