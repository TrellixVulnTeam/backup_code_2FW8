import initRedux from "../../utils/redux/initRedux";

const initialState = {
  list: [],
  loading: false,
  error: false,
}

const LOAD_USER_POST = 'load_user_post';
const LOAD_USER_POST_SUCCESS = 'load_user_post_success';
const LOAD_USER_POST_ERROR = 'load_user_post_error';

export function loadUserPosts(author_id) {
  return {
    types: [LOAD_USER_POST, LOAD_USER_POST_SUCCESS, LOAD_USER_POST_ERROR],
    url: `http://localhost:5000/foods/user/${author_id}`,
  }
}

const handlers = {};

handlers[LOAD_USER_POST] = (state, action) => {
  return {
    ...state,
    loading: true,
    error: false,
  }
};

handlers[LOAD_USER_POST_SUCCESS] = (state, { payload }) => {
  return {
    ...state,
    loading: false,
    error: false,
    list: payload,
  }
};

handlers[LOAD_USER_POST_ERROR] = (state, { payload }) => {
  return {
    ...state,
    loading: false,
    error: true,
  }
};

const reducers = initRedux(handlers, initialState);
export default reducers;