import initRedux from "../../utils/redux/initRedux";

const initialState = {
  user: null,
  loading: false,
  error: false,
}

const LOAD_USER = 'load_user';
const LOAD_USER_SUCCESS = 'load_user_success';
const LOAD_USER_ERROR = 'load_user_error';
const LOGOUT_USER = 'logout_user';

export function loadUser(callback = () => { }) {
  return {
    types: [LOAD_USER, LOAD_USER_SUCCESS, LOAD_USER_ERROR],
    url: `http://localhost:5000/user`,
    headers: {
      'Content-Type': 'application/json',
    },
    callback
  }
}

export function logout() {
  return {
    type: LOGOUT_USER,
  }
}

const handlers = {};

handlers[LOGOUT_USER] = (state, action) => {
  localStorage.removeItem('token');
  return {
    ...state,
    user: null
  }
}

handlers[LOAD_USER] = (state, action) => {
  return {
    ...state,
    loading: true,
    error: false,
  }
};

handlers[LOAD_USER_SUCCESS] = (state, { payload }) => {
  return {
    ...state,
    loading: false,
    error: false,
    user: payload,
  }
};

handlers[LOAD_USER_ERROR] = (state, { payload }) => {
  return {
    ...state,
    loading: false,
    error: true,
  }
};

const reducers = initRedux(handlers, initialState);
export default reducers;