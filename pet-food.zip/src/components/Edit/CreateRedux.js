const initialState = {
  done: false,
  loading: false,
  error: false,
}

const PUBLISH_ARTICLE = 'publish_article';
const PUBLISH_ARTICLE_SUCCESS = 'publish_article_success';
const PUBLISH_ARTICLE_ERROR = 'publish_article_error';
const PUBLISH_ARTICLE_DONE = 'publish_article_done';

export function publishArticle(title, content) {
  return {
    types: [PUBLISH_ARTICLE, PUBLISH_ARTICLE_SUCCESS, PUBLISH_ARTICLE_ERROR],
    url: `http://localhost:5000/foods`,
    method: 'post',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      title,
      content
    })
  }
}

export function publishDone() {
  return {
    type: PUBLISH_ARTICLE_DONE
  }
}

export default function (state = initialState, action) {
  const { type, payload } = action;
  if (type === PUBLISH_ARTICLE) {
    return {
      ...state,
      loading: true,
      error: false,
      done: false,
    }
  } else if (type === PUBLISH_ARTICLE_SUCCESS) {
    return {
      ...state,
      loading: false,
      error: false,
      done: true,
    };
  } else if (type === PUBLISH_ARTICLE_ERROR) {
    return {
      ...state,
      loading: false,
      error: true,
      done: false,
    }
  } else if (PUBLISH_ARTICLE_DONE) {
    return {
      ...state,
      done: false,
    }
  } else {
    return state;
  }
}