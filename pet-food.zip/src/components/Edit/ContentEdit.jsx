import React from 'react';
import classes from './index.module.css';
import { Input } from '@material-ui/core';

export default function ({ onChange, ...rest }) {

  const handleChange = e => {
    onChange(e.target.value);
  }

  return (
    <Input {...rest} onChange={handleChange} />
  );
}