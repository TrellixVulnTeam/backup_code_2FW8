import initRedux from "../../utils/redux/initRedux";

const initialState = {
  done: false,
  loading: false,
  error: false,
}

const UPDATE_POST = 'update_post';
const UPDATE_POST_SUCCESS = 'update_post_success';
const UPDATE_POST_ERROR = 'update_post_error';
const UPDATE_POST_DONE = 'update_post_done';

export function updateArticle(id, title, content) {
  return {
    types: [UPDATE_POST, UPDATE_POST_SUCCESS, UPDATE_POST_ERROR],
    url: `http://localhost:5000/foods/update/${id}`,
    method: 'post',
    headers: {
      'Content-Type': `application/json`,
    },
    body: JSON.stringify({
      title,
      content
    })
  }
}

export function updateDone() {
  return {
    type: UPDATE_POST_DONE,
  }
}

const handlers = {};

handlers[UPDATE_POST] = (state, action) => {
  return {
    ...state,
    loading: true,
    error: false,
    done: false,
  }
};

handlers[UPDATE_POST_SUCCESS] = (state, { payload }) => {
  return {
    ...state,
    loading: false,
    error: false,
    done: true,
  }
};

handlers[UPDATE_POST_ERROR] = (state, { payload }) => {
  return {
    ...state,
    loading: false,
    error: true,
    done: false,
  }
};

handlers[UPDATE_POST_DONE] = (state, { payload }) => {
  return {
    ...state,
    done: true,
  }
};

const reducers = initRedux(handlers, initialState);
export default reducers;