import React from 'react';
import { FormControl, InputLabel, OutlinedInput } from '@material-ui/core';
import classes from './index.module.css';

export default function ({ onChange, value, ...rest }) {

  const handleChange = e => {
    onChange(e.target.value);
  }

  return (
    <FormControl variant="outlined" {...rest}>
      <InputLabel className={classes.labelTitle} htmlFor="component-outlined">
        Title
      </InputLabel>
      <OutlinedInput
        id="component-outlined"
        value={value}
        onChange={handleChange}
      />
    </FormControl>
  )
}