import React from 'react';
import { Card, CardContent, Typography, Button, makeStyles, CardActions } from '@material-ui/core';

const useStyles = makeStyles({
  card: {
    boxSizing: 'border-box',
    marginTop: 20
  },
  bullet: {
    display: 'inline-block',
    margin: '0 2px',
    transform: 'scale(0.8)',
  },
  title: {
    fontSize: 14,
  },
  pos: {
    marginBottom: 12,
  },
});

export default function ({ title, content, author, onClick}) {
  const classes = useStyles();

  return (
    <Card className={classes.card}>
      <CardContent>
        <Typography variant="h5" component="h2">
          {title}
      </Typography>
        <Typography className={classes.pos} color="textSecondary">
          author: {author}
    </Typography>
        <Typography variant="body2" component="p">
          {content}
        </Typography>
      </CardContent>
      <CardActions>
        <Button size="small" onClick={onClick}>Look</Button>
      </CardActions>
    </Card>
  )
}