import jsonpFetch from "redux-composable-fetch/lib/jsonpFetch";

const initialState = {
  foods: [],
  loading: false,
  error: false,
}

const LOAD_FOODS = 'load_foods';
const LOAD_FOODS_SUCCESS = 'load_foods_success';
const LOAD_FOODS_ERROR = 'load_foods_error';

export function loadFood(author_id = -1) {
  let url = `http://localhost:5000/foods`;
  if (author_id > -1) {
    url = `http://localhost:5000/foods/${author_id}`
  }

  return {
    types: [LOAD_FOODS, LOAD_FOODS_SUCCESS, LOAD_FOODS_ERROR],
    url
  }
}

export function search(keyword) {
  return {
    types: [LOAD_FOODS, LOAD_FOODS_SUCCESS, LOAD_FOODS_ERROR],
    url: `http://localhost:5000/search/${keyword}`
  }
}

const handlers = {};


handlers[LOAD_FOODS] = (state, action) => {
  return {
    ...state,
    loading: true,
    error: false,
  }
}

handlers[LOAD_FOODS_SUCCESS] = (state, { payload }) => {
  return {
    ...state,
    loading: true,
    error: false,
    foods: payload
  }
}

handlers[LOAD_FOODS_ERROR] = (state, { payload }) => {
  return {
    ...state,
    loading: false,
    error: true
  }
}

export default function (state = initialState, action) {
  const { type } = action;

  if (Reflect.has(handlers, type)) {
    return handlers[type](state, action);
  }
  return state;
}