import React from 'react';
import FoodItem from './FoodItem';
import { Paper } from '@material-ui/core';
export default function ({ foods = [], onClick }) {
  
  if (foods.length === 0) {
    return (
      <Paper style={{
        height: 300,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
      }}>
        No Content!
      </Paper>
    )
  }
  return (
    <div>
      {foods.map((food, index) => <FoodItem key={index} {...food} onClick={() => onClick(food)} />)}
    </div>
  )
}