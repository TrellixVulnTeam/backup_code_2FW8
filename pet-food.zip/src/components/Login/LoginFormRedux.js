import initRedux from "../../utils/redux/initRedux";

const initialState = {
  token: null,
  loading: false,
  error: false,
}

const LOGIN = 'load_login';
const LOGIN_SUCCESS = 'load_login_success';
const LOGIN_ERROR = 'load_login_error';

export function login(user, callback) {
  return {
    types: [LOGIN, LOGIN_SUCCESS, LOGIN_ERROR],
    url: `http://localhost:5000/auth`,
    method: 'post',
    body: JSON.stringify(user),
    headers: {
      'Content-Type': 'application/json'
    },
    callback
  }
}

const handlers = {};

handlers[LOGIN] = (state, action) => {
  return {
    ...state,
    loading: true,
    error: false,
  }
};

handlers[LOGIN_SUCCESS] = (state, { payload }) => {
  return {
    ...state,
    loading: false,
    error: false,
    token: payload,
  }
};

handlers[LOGIN_ERROR] = (state, { payload }) => {
  return {
    ...state,
    loading: false,
    error: true,
  }
};

const reducers = initRedux(handlers, initialState);
export default reducers;