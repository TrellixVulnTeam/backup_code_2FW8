import initRedux from "../../utils/redux/initRedux";

const initialState = {
  status: null,
  loading: false,
  error: false,
}

const REGISTER = 'register';
const REGISTER_SUCCESS = 'register_success';
const REGISTER_ERROR = 'register_error';

export function register(user, callback) {
  return {
    types: [REGISTER, REGISTER_SUCCESS, REGISTER_ERROR],
    url: `http://localhost:5000/register`,
    method: 'post',
    body: JSON.stringify(user),
    headers: {
      'Content-Type': 'application/json'
    },
    callback
  }
}

const handlers = {};

handlers[REGISTER] = (state, action) => {
  return {
    ...state,
    loading: true,
    error: false,
  }
};

handlers[REGISTER_SUCCESS] = (state, { payload }) => {
  return {
    ...state,
    loading: false,
    error: false,
    status: payload,
  }
};

handlers[REGISTER_ERROR] = (state, { payload }) => {
  return {
    ...state,
    loading: false,
    error: true,
  }
};

const reducers = initRedux(handlers, initialState);
export default reducers;