import React, { useState } from 'react';
import { FormControl, InputLabel, Input, Button, Link } from '@material-ui/core';
import styles from './index.module.css';

const nullCallback = () => { }
export default function ({ isLogin = true, onSignup = nullCallback, onLogin = nullCallback }) {
  const componentType = {
    'login': {
      text: "Login",
      change: 'signup'
    },
    'signup': {
      text: "Signup",
      change: 'login'
    }
  }

  const [cs, setCs] = useState(isLogin ? componentType['login'] : componentType['signup']);
  const [user, setUser] = useState({
    username: '',
    password: '',
  })

  const setUsername = username => setUser({ ...user, username });
  const setPassword = password => setUser({ ...user, password });

  const handleLogin = () => onLogin(user.username, user.password);
  const handleSignup = () => onSignup(user.username, user.password);
  return (
    <div className={styles.root}>
      <div className={styles.item}>
        <FormControl fullWidth>
          <InputLabel htmlFor="component-simple">Name</InputLabel>
          <Input value={user.username} onChange={(e) => setUsername(e.target.value)} />
        </FormControl>
      </div>
      <div className={styles.item}>
        <FormControl fullWidth>
          <InputLabel htmlFor="component-simple">Password</InputLabel>
          <Input type="password" value={user.password} onChange={(e) => setPassword(e.target.value)} />
        </FormControl>
      </div>
      <div className={styles.item}>
        <Button variant="contained" color="primary" onClick={cs.text === 'Login' ? handleLogin : handleSignup}>{cs.text}</Button>
        <Button onClick={() => setCs(componentType[cs.change])}>Go {cs.change}</Button>
      </div>
    </div>
  )
}