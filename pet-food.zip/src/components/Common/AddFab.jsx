import React from 'react';
import { Fab } from '@material-ui/core';
import { Add } from '@material-ui/icons';
import classes from './AddFab.module.css'
export default function ({ onClick }) {
  return (
    <Fab onClick={onClick} color="primary" aria-label="add" className={classes.fab} style={{
      position: 'fixed'
    }}>
      <Add />
    </Fab>
  )
}