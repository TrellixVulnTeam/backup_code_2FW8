import React, { useState } from 'react';
import { AppBar, Toolbar, Typography, Button, makeStyles, IconButton, Menu, MenuItem, Link, InputBase } from '@material-ui/core';
import { connect } from 'react-redux';
import { AccountCircle, Search } from '@material-ui/icons';
import { infoAction } from '../../views/UserRedux';
import { withRouter } from 'react-router';
import { listAction } from '../../views/HomeRedux';


const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1,
  },
  menuButton: {
    marginRight: theme.spacing(2),
  },
  title: {
    flex: 1,
  },
  searchRoot: {
    position: 'relative',
    flexGrow: 1,
  },
  search: {
    borderRadius: theme.shape.borderRadius,
    backgroundColor: 'rgba(0, 0, 0, .15)',
    padding: 2,
    marginRight: theme.spacing(2),
    marginLeft: 0,
    color: 'white',
    width: '100%',
    '&:hover': {
      backgroundColor: 'rgba(0, 0, 0, .25)',
    }
  },
  searchIcon: {
    position: 'absolute',
    right: 12,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    height: '100%',
    padding: '0 10px',
    zIndex: 99,
  }
}));

function Header({ user, logout, history, search, loadFood }) {
  const classes = useStyles();
  const [anchorEl, setAnchorEl] = useState(null);
  const [searchKey, setSearchKey] = useState("");
  const isMenuOpen = Boolean(anchorEl);

  const handleMenuOpen = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleSearchKeyChange = e => {
    setSearchKey(e.target.value);
  }

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    logout();
    handleMenuClose();
  }

  const goUserInfo = () => {
    history.push('/user');
    handleMenuClose();
  }

  const handleSearch = () => {
    if (searchKey === '') {
      loadFood();
    } else {
      search(searchKey);
    }
  }

  const goHome = () => {
    history.push('/');
  }

  const menu = (
    <Menu
      anchorEl={anchorEl}
      anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      keepMounted
      transformOrigin={{ vertical: 'top', horizontal: 'right' }}
      open={isMenuOpen}
      onClose={handleMenuClose}
    >
      <MenuItem onClick={goUserInfo}>My Account</MenuItem>
      <MenuItem onClick={handleLogout}>Logout</MenuItem>
    </Menu>
  )

  return (
    <AppBar position="fixed">
      <Toolbar>
        <Typography variant="h6" className={classes.title} onClick={goHome}>
          Pet Foods
        </Typography>
        <div className={classes.searchRoot}>
          <IconButton className={classes.searchIcon} onClick={handleSearch}>
            <Search />
          </IconButton>
          <InputBase placeholder="Search..." className={classes.search} value={searchKey} onChange={handleSearchKeyChange} />
        </div>
        {
          user ?
            <IconButton
              aria-label="account of current user"
              aria-controls="menu-appbar"
              aria-haspopup="true"
              onClick={handleMenuOpen}
              color="inherit"
            >
              <AccountCircle />
              {user.username}
            </IconButton> :
            <Link color="inherit" href="/login">Login</Link>
        }
        {menu}
      </Toolbar>
    </AppBar>
  );
}

export default withRouter(connect(state => ({
  user: state.user.info.user,
}), {
  ...infoAction,
  ...listAction,
})(Header));