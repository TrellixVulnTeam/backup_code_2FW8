
(function(window,document,Laya){
	var __un=Laya.un,__uns=Laya.uns,__static=Laya.static,__class=Laya.class,__getset=Laya.getset,__newvec=Laya.__newvec;

	var Button=laya.editorUI.Button,Event=laya.events.Event;
	//继承button组件
	//class component.UIButton extends laya.editorUI.Button
	var UIButton=(function(_super){
		function UIButton(skin,label){
			this.scaleTime=100;
			(label===void 0)&& (label="");
			UIButton.__super.call(this,skin,label);
			this.stateNum=1;
			this.on("mousedown",this,this.scaleSmal);
			this.on("mouseup",this,this.scaleBig);
			this.on("mouseout",this,this.scaleBig);
			this.labelBold=true;
			this.labelSize=36;
		}

		__class(UIButton,'component.UIButton',_super);
		var __proto=UIButton.prototype;
		__proto.scaleBig=function(){}
		//Tween.to(this,{scaleX:1,scaleY:1},scaleTime);
		__proto.scaleSmal=function(){}
		return UIButton;
	})(Button)



})(window,document,Laya);
